//
//  fish.hpp
//  Boids
//
//  Created by chenyuwei on 2022/3/17.
//

#ifndef fish_hpp
#define fish_hpp

//#include <stdio.h>
#include <boid.hpp>

class Fish:public Boid
{
public:

    void draw();
    

    
    
};


#endif /* fish_hpp */
