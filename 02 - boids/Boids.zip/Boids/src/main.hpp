//
//  main.hpp
//  Boids
//
//  Created by chenyuwei on 2022/3/17.
//

#ifndef main_hpp
#define main_hpp

#include <stdio.h>

#endif /* main_hpp */
